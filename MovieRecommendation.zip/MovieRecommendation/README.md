# MovieRecommendation

## This is a movie recommendation algorithm that is implemented with KNN Classifier and cross-validation methods to predict, as close as possible, how these production companies generate the revenue streams. 




