#! /usr/bin/env python

import warnings
import pandas as pd
import statistics
import numpy as np
import matplotlib
from matplotlib import pyplot as plt
from matplotlib.pyplot import figure
from matplotlib.colors import ListedColormap
from sklearn.decomposition import PCA

import seaborn as sns
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
from sklearn.feature_selection import mutual_info_classif
from sklearn.feature_selection import f_regression
from sklearn.feature_selection import f_classif
from sklearn.preprocessing import OrdinalEncoder
from sklearn.preprocessing import PowerTransformer
from sklearn.compose import TransformedTargetRegressor
from sklearn.model_selection import train_test_split
from sklearn.linear_model import HuberRegressor, LinearRegression
from sklearn import metrics
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from src import helper
from src import cluster
import os
import sys
cmap_light = ListedColormap(["orange", "cyan", "cornflowerblue"])
cmap_bold = ["darkorange", "c", "darkblue"]
cmd_movie = "./"


# -------------------------------------------------------------------------------- # sklearn Modules
# -------------------------------------------------------------------------------- # Custom Modules

plt.style.use('ggplot')
RUN_TYPE = "Colab"
y_cols = ["gross", "budget"]
X_col = ["rating", "score", "genre"]
# X_col = ["rating", "score", "genre", "company"]

# ]
h = 0.2  # step size in the mesh


def cleanLabels(df, col_name):
    target_names = df.copy()[col_name]
    sum_gross = sum(df[col_name].to_numpy())
    data_sorted = np.sort(df[col_name])

    b1 = int(len(data_sorted) * 1/3)
    b2 = int(len(data_sorted) * 2/4)
    b3 = int(len(data_sorted) * 3/4)

    # print(data_sorted, b1, b2)
    avg_gross = helper.mean(df[col_name].to_numpy())
    _data = df[col_name].to_numpy()
    for index, _ in enumerate(_data):
        if _data[index] >= data_sorted[b3]:
            target_names[index] = f"Level 4"
            _data[index] = 3
        elif _data[index] >= data_sorted[b2]:
            target_names[index] = f"Level 2"
            _data[index] = 2
        elif _data[index] >= data_sorted[b1]:
            target_names[index] = f"Level 2"
            _data[index] = 1
        else:
            target_names[index] = f"Level 1"
            _data[index] = 0

        # else:
        #     target_names[index] = f"Level 3"
        #     _data[index] = 3

        # if _data[index] >= avg_gross/2:
        #     target_names[index] = f"Level 1"
        #     _data[index] = 1
        # else:
        #     target_names[index] = f"Level 0"
        #     _data[index] = 0

    df[col_name] = _data
    return df, target_names


def clean_df(_DATA_):
    _DATA_ = helper.removeNaN(_DATA_, "gross")
    _DATA_ = helper.removeNaN(_DATA_, "budget")
    _DATA_ = helper.removeNaN(_DATA_, "rating")
    _DATA_ = helper.removeNaN(_DATA_, "score")
    _DATA_ = helper.removeNaN(_DATA_, "company")

    # company

    _DATA_, target_gross = cleanLabels(_DATA_, "gross")
    _DATA_, target_budget = cleanLabels(_DATA_, "budget")

    df_rating = [str(i) for i in _DATA_.rating.values]
    df_genre = [str(i) for i in _DATA_.genre.values]
    df_company = [str(i) for i in _DATA_["company"].values]
    df_company = [str(i) for i in _DATA_["company"].values]
    df_score = [str(i) for i in _DATA_["score"].values]

    ratingLT = list(set(df_rating))
    companyLT = list(set(df_company))
    genreLT = list(set(df_genre))
    scoreLT = list(set(df_score))

    print(scoreLT)

    for idx, row in enumerate(_DATA_.rating):
        df_rating[idx] = ratingLT.index(row)

    for idx, row in enumerate(_DATA_.genre):
        df_genre[idx] = genreLT.index(row)

    for idx, row in enumerate(_DATA_.company):
        df_company[idx] = companyLT.index(row)

    for idx, row in enumerate(_DATA_["score"].values):
        df_score[idx] = scoreLT.index(str(row))

    _DATA_["rating"] = df_rating
    _DATA_["genre"] = df_genre
    _DATA_["company"] = df_company
    _DATA_["score"] = df_score

    return _DATA_, target_gross, target_budget


def runClustering(DATA, target_gross, target_budget):
    # y_col = y_cols[0:]
    for y_col in range(1):
        y_col = y_cols[y_col]
        # print (f"Generating KNN with\n   ==> label_col = {y_col}")
        # print(DATA)
        # print(y_col)

        y = DATA[y_col].to_numpy()
        X = DATA[X_col].to_numpy()

        pca = PCA(2)
        X = pca.fit_transform(X)
        print(X)
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.3, random_state=42)
        KNN = cluster.train(X, y)
        # y_pred = KNN.predict(X_test)
        # crossValResults = cluster.Eval.cross_val(KNN, X_test, y_test)

        x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
        y_min, y_max = X[:, 1].min() - 1,  X[:, 1].max() + 1
        xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                             np.arange(y_min, y_max, h))
        zz = np.c_[xx.ravel(), yy.ravel()]
        Z = KNN.predict(zz)

        # print(xx.ravel().shape, yy.ravel().shape)
        # print(zz.shape)
        # print(X.shape, y.shape)

        Z = Z.reshape(xx.shape)         # Put the result into a color plot
        plt.figure(figsize=(8, 6))
        print(xx)
        print(yy)
        print(Z)

        plt.contourf(xx, yy, Z, cmap=cmap_light)
        target_names = list(set(y))

        print(DATA[y_col])

        # # Plot also the training points
        sns.scatterplot(
            x=X[:, 0],
            y=X[:, 1],
            hue=y,
            # palette=cmap_bold,
            palette=sns.color_palette(
                'coolwarm', n_colors=4),

            alpha=1.0,
            edgecolor="black",
        )

        plt.xlim(xx.min(), xx.max())
        plt.ylim(yy.min(), yy.max())
        # plt.title(
        #     "3-Class classification (k = %i, weights = '%s')" % (n_neighbors, weights)
        # )
        # plt.xlabel(iris.feature_names[0])
        # plt.ylabel(iris.feature_names[1])
        plt.show()

        # # Put the result into a color plot
        # Z = Z.reshape(xx.shape)
        # pl.figure(1, figsize=(4, 3))
        # pl.set_cmap(pl.cm.Paired)
        # pl.pcolormesh(xx, yy, Z)

        # # Plot also the training points
        # pl.scatter(X[:, 0], X[:, 1], c=Y)
        # pl.xlabel('Sepal length')
        # pl.ylabel('Sepal width')

        # pl.xlim(xx.min(), xx.max())
        # pl.ylim(yy.min(), yy.max())
        # pl.xticks(())
        # pl.yticks(())

        # pl.show()


def main():

    DATA_PATH = "data/movies_v1.csv"
    DATA_ORIGINAL_PATH = "data/movies_original.csv"
    cwd = os.getcwd()

    DATA_PATH = os.path.join(cmd_movie, DATA_PATH)
    # DATA_ORIGINAL_PATH = os.path.join(cmd_movie, DATA_ORIGINAL_PATH)

    print(DATA_PATH)
    DATA = pd.read_csv(DATA_PATH)
    # DATA_ORIGINAL = pd.read_csv(DATA_ORIGINAL_PATH)
    # ------------------------------------------------------------ #
    print("Booting up the Movie Recommended System ...")
    print(f"{DATA} ")

    data, t_gross, t_budget = clean_df(DATA)
    runClustering(data, t_gross, t_budget)


if __name__ == "__main__":
    main()

    # print("--------------------------------")
    # print (f"DATA -- ORIGINAL")
    # # KNN, X_test, y_test = runClustering(clean_df(DATA_ORIGINAL))
